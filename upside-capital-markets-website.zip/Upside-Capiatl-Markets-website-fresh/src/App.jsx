import { Button } from '@/components/ui/button.jsx'
import './App.css'

function App() {
  const services = [
    {
      number: "01",
      title: "Investment Advisory",
      description: "Providing expert guidance on portfolio optimization, risk management, and capital allocation strategies."
    },
    {
      number: "02", 
      title: "Acquisition and Disposition",
      description: "Leveraging our extensive network and market intelligence to facilitate successful transactions."
    },
    {
      number: "03",
      title: "Asset Management", 
      description: "Actively managing properties to enhance performance and maximize returns for our clients."
    },
    {
      number: "04",
      title: "Research and Insights",
      description: "Providing data-driven market analysis and thought leadership to inform our clients' investment decisions."
    },
    {
      number: "05",
      title: "Marketing and Communication",
      description: "Our network of brand experts will bring your projects to qualified investors and targeted demographics."
    },
    {
      number: "06",
      title: "Architecture & Design",
      description: "Award-winning world-renowned firms leverage cutting-edge strategies for best in class results."
    },
    {
      number: "07",
      title: "Permitting & Entitlements",
      description: "Decades of Experience, hundreds of projects offering execution as a service."
    },
    {
      number: "08",
      title: "Pro forma Analysis & Support",
      description: "Data verification, project development and comprehensive financial modeling."
    },
    {
      number: "09",
      title: "Joint Ventures & Strategic Partnership",
      description: "Achieve highest outcomes and new levels of growth through strategic collaborations."
    },
    {
      number: "10",
      title: "Equity & Debt Finance",
      description: "Refinance, LBO, GP & LP sales, credit lines and cross collateralization solutions."
    },
    {
      number: "11",
      title: "Hiring & Recruiting Support",
      description: "Project specific or new markets - leverage our expertise finding capable and dialed in talent."
    },
    {
      number: "12",
      title: "Construction Management",
      description: "Top-tier pre-construction resources minimize risk and deliver exceptional results."
    }
  ];

  const principles = [
    {
      title: "Goal-Oriented",
      description: "We are laser-focused on helping our clients achieve their investment objectives."
    },
    {
      title: "Innovative",
      description: "Our forward-thinking strategies and data-driven approach set us apart from the competition."
    },
    {
      title: "Collaborative", 
      description: "We work closely with our clients to foster long-term, mutually beneficial relationships."
    },
    {
      title: "Principled",
      description: "Integrity, transparency, and accountability are the cornerstones of our business."
    }
  ];

  const projects = [
    {
      location: "Westport, CT",
      type: "Mixed use development",
      amount: "$12 million preferred equity raise",
      completion: "completion in late 2024"
    },
    {
      location: "New Haven, CT", 
      type: "Mixed use",
      amount: "$3 Million preferred Equity raise",
      completion: "completion early 2025"
    },
    {
      location: "Manchester, NH",
      type: "Opportunity Zone Residential 6 story ground up",
      amount: "$20 m equity raise plus debt",
      completion: "completion target early/mid 2025"
    }
  ];

  return (
    <div className="min-h-screen bg-white">
      {/* Navigation */}
      <nav className="fixed top-0 w-full bg-white/95 backdrop-blur-sm border-b border-gray-100 z-50">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex justify-between items-center">
            <div className="text-2xl font-bold text-black tracking-tight">
              Upside Capital Markets
            </div>
            <div className="hidden md:flex space-x-8">
              <a href="#services" className="text-gray-600 hover:text-black transition-colors font-medium">Services</a>
              <a href="#about" className="text-gray-600 hover:text-black transition-colors font-medium">About</a>
              <a href="#projects" className="text-gray-600 hover:text-black transition-colors font-medium">Projects</a>
              <a href="#contact" className="text-gray-600 hover:text-black transition-colors font-medium">Contact</a>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="pt-32 pb-20 px-6">
        <div className="max-w-7xl mx-auto text-center">
          <h1 className="text-6xl md:text-8xl font-bold text-black mb-8 tracking-tight leading-none">
            Upside Capital<br />Markets
          </h1>
          <p className="text-xl md:text-2xl text-gray-600 mb-12 max-w-3xl mx-auto font-light">
            Elevating Commercial Real Estate Investments with Unparalleled Expertise and Innovative Strategies
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="px-8 py-4 text-lg font-medium bg-black text-white hover:bg-gray-800 transition-colors">
              Explore Our Services
            </Button>
            <Button variant="outline" size="lg" className="px-8 py-4 text-lg font-medium border-2 border-black text-black hover:bg-black hover:text-white transition-colors">
              Join Our Community
            </Button>
          </div>
        </div>
      </section>

      {/* Welcome Section */}
      <section className="py-20 px-6 bg-gray-50">
        <div className="max-w-7xl mx-auto text-center">
          <h2 className="text-4xl md:text-5xl font-bold text-black mb-16 tracking-tight">
            Welcome to the most innovative Capital Markets Commercial Real Estate Platform
          </h2>
          <div className="grid md:grid-cols-3 gap-12">
            <div>
              <h3 className="text-2xl font-bold text-black mb-4">Comprehensive Expertise</h3>
              <p className="text-gray-600 leading-relaxed">
                Our team of seasoned professionals brings decades of experience in commercial real estate, capital markets, and investment strategy.
              </p>
            </div>
            <div>
              <h3 className="text-2xl font-bold text-black mb-4">Innovative Approach</h3>
              <p className="text-gray-600 leading-relaxed">
                We leverage cutting-edge data analytics and market insights to deliver customized solutions that maximize returns for our clients.
              </p>
            </div>
            <div>
              <h3 className="text-2xl font-bold text-black mb-4">Developer-Centric Focus</h3>
              <p className="text-gray-600 leading-relaxed">
                Our unwavering commitment to our clients' success is the cornerstone of our business. We work tirelessly to empower them to achieve extraordinary results.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-20 px-6">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-4xl md:text-5xl font-bold text-black mb-16 text-center tracking-tight">
            Our Comprehensive Suite of Services
          </h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <div key={index} className="group">
                <div className="text-6xl font-bold text-gray-200 mb-4 group-hover:text-black transition-colors duration-300">
                  {service.number}
                </div>
                <h3 className="text-xl font-bold text-black mb-3">
                  {service.title}
                </h3>
                <p className="text-gray-600 leading-relaxed">
                  {service.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Principles Section */}
      <section id="about" className="py-20 px-6 bg-gray-50">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-4xl md:text-5xl font-bold text-black mb-16 text-center tracking-tight">
            Empowering Investors and Developers to Achieve New Heights
          </h2>
          <div className="grid md:grid-cols-2 gap-12">
            {principles.map((principle, index) => (
              <div key={index} className="text-center">
                <h3 className="text-2xl font-bold text-black mb-4">
                  {principle.title}
                </h3>
                <p className="text-gray-600 leading-relaxed">
                  {principle.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Current Projects Section */}
      <section id="projects" className="py-20 px-6">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-4xl md:text-5xl font-bold text-black mb-16 text-center tracking-tight">
            Current Projects
          </h2>
          <div className="space-y-8">
            {projects.map((project, index) => (
              <div key={index} className="border-l-4 border-black pl-8 py-4">
                <h3 className="text-2xl font-bold text-black mb-2">
                  {project.location}
                </h3>
                <p className="text-lg text-gray-800 mb-1">
                  {project.type}
                </p>
                <p className="text-lg font-semibold text-black mb-1">
                  {project.amount}
                </p>
                <p className="text-gray-600">
                  {project.completion}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 px-6 bg-black text-white">
        <div className="max-w-7xl mx-auto text-center">
          <h2 className="text-4xl md:text-5xl font-bold mb-8 tracking-tight">
            Connect with Us Today
          </h2>
          <p className="text-xl text-gray-300 mb-12 max-w-2xl mx-auto">
            Ready to elevate your commercial real estate investments? Let's discuss how we can help you achieve extraordinary results.
          </p>
          
          {/* Contact Information */}
          <div className="mb-12 space-y-6">
            <div className="flex flex-col md:flex-row justify-center items-center gap-8 md:gap-16">
              <div className="flex items-center gap-3">
                <div className="w-6 h-6 border-2 border-white rounded-full flex items-center justify-center">
                  <div className="w-2 h-2 bg-white rounded-full"></div>
                </div>
                <a href="mailto:joed@upside-re-development.com" className="text-xl text-white hover:text-gray-300 transition-colors">
                  joed@upside-re-development.com
                </a>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-6 h-6 border-2 border-white rounded-full flex items-center justify-center">
                  <div className="w-2 h-2 bg-white rounded-full"></div>
                </div>
                <a href="tel:617.894.0445" className="text-xl text-white hover:text-gray-300 transition-colors">
                  617.894.0445
                </a>
              </div>
            </div>
          </div>
          
          <Button size="lg" className="px-8 py-4 text-lg font-medium bg-white text-black hover:bg-gray-100 transition-colors">
            Get Started
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 px-6 bg-gray-900 text-white">
        <div className="max-w-7xl mx-auto text-center">
          <div className="text-2xl font-bold mb-4 tracking-tight">
            Upside Capital Markets
          </div>
          <p className="text-gray-400">
            © 2024 Upside Capital Markets. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  )
}

export default App

